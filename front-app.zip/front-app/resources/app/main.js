const { app, BrowserWindow } = require('electron');
const { spawn } = require('child_process');

app.disableHardwareAcceleration(false);

let mainWindow;

app.on('ready', () => {
  mainWindow = new BrowserWindow(
	{
        width: 980,
        height: 763,
        icon: __dirname + '/icn.png',
        autoHideMenuBar: true,
        resizable: false,
	    webPreferences: {
      		nodeIntegration: true,
      		contextIsolation: true,
    	}, 
    }
);

  const command = 'dir';
  const childProcess = spawn(command, { shell: true });

  childProcess.stdout.on('data', (data) => {
    console.log(`stdout: ${data}`);
  });

  childProcess.stderr.on('data', (data) => {
    console.error(`stderr: ${data}`);
  });

  mainWindow.loadFile('./html/index.html');

  mainWindow.webContents.openDevTools();

});