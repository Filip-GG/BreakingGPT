let _T = {
    api_domain: 'http://127.0.0.1:8000',
    inGen: 0,
    template_dir: "../img"
}
let tpl = {
    errloadpage: `<div class="aiErrLoadPage">Невозможно загрузить список файлов.<br />Попросите администратора проверить,<br />доступен ли сервер генерации ответов.<br /><div class="imRMActions">

                                    <action onclick="main.domStarted();">
                                        <span class="fi-rr-arrows-repeat" data-icon=""></span>
                                        <span data-motd="">Перезагрузить приложение</span>
                                    </action>
                                </div></div>`,
    file: `<div class="wall_attach_photo wall_attach_doc" title="{title}">
<div class="wall_attach_del" title="Удалить файл" onclick="api.attach_deleteP('{title}')"></div><div class="doc_attach_ic"></div>
<div class="doc_attach_text" >{title}</div></div>`,
    errbl: `<div class="err_red">{text}</div>`,
    slide: `<div class="swiper-slide revUiBlock">
<div style="
    display: flex;
    flex-direction: column;
"><small><span class=" fi-rr-comment-user fiAiIconU"></span>Вы:</small>
<div class="mTop10"></div>
<div class="aiCardText">{text}</div>
<div class="aiCardSep"></div>
<div class="mTop15"></div>
<small><span class="fi-rr-chatbot fiAiIconU"></span>AI:</small>
<div class="mTop10"></div>
<div class="aiCardText AIText">Подождите пожалуйста, мы генерируем ответ.<br /><span style="
    color: var(--text_color);
    opacity: 1;
    visibility: visible;padding: 0;
" id="im_typograf">Этот процесс может занять некоторое время</span></div>

</div>

</div>`,
    prbar1: `<green>
                                        <label>
                                            <count>1</count>
                                            <span>Введите запрос</span>
                                        </label>
                                    </green>
                                    <gray>
                                        <label>
                                            <count>2</count>
                                            <span>Получите ответ</span>
                                        </label>
                                    </gray>`,
    prbar2: `<green>
                                        <label>
                                            <count>1</count>
                                            <span>Введите запрос</span>
                                        </label>
                                    </green>
                                    <green>
                                        <label>
                                            <count>2</count>
                                            <span>Получите ответ</span>
                                        </label>
                                    </green>`,
    mpage: `<div class="revUiBlock recomWrBlock">

                                <div class="recomBlock">
                                    <span class="recomh1">Введите Ваш запрос:</span>

                                    <div>
                                        <input id="mPromptInp" type="text" class="mainPageTxtInp" placeholder="Для обработки, нажмите Enter" onkeypress="if(event.keyCode == 13)api.query();" autocomplete="off" readonly onfocus="this.removeAttribute('readonly')" onblur="this.setAttribute('readonly', '')">
                                        
                                    </div>
                                    
                                    <div class="swiper mySwiper mTop15">
                                        <div class="swiper-wrapper" id="sliderCont"></div>
                                    </div>
  
                                </div>
                 
                                <progress_bar id="aiPrBar">
                                    <gray>
                                        <label>
                                            <count>1</count>
                                            <span>Введите запрос</span>
                                        </label>
                                    </gray>
                                    <gray>
                                        <label>
                                            <count>2</count>
                                            <span>Получите ответ</span>
                                        </label>
                                    </gray>
                                </progress_bar>

                            </div>`,
    mgen: `
<div class="recomBlock">
                                    
                                    <div class="nano" data-im-scroll>
<div class="im_scroll data_im_scroll">

<div id="prevMsg"></div>
<div id="im_scroll">

<onemessage class="im_msg im_f_in_row  position_rel  rowOwnMsg " style="">
<a class="oim_bigp_l  "><img onerror="this.src='/templates/Default/images/spacer.gif';this.classList.add('noSources');this.setAttribute('ordSrc', this.src);" src="https://tidevk.ru/uploads/users/1/50_hTrrxYyol9w0Ibxe72jnmWg4YClw8yHn.webp">
</a><div class="oim_bigp_r"><div class="msg_headIM"><left-h-im>
<span data-name="">Пользователь</span>
</left-h-im>
<right-h-im class="position_rel"><span data-date=""></span>
</right-h-im></div><div class="msg_textIM">
<span class="im_msg_textPart">{gen-text}</span></div></div></onemessage>

    <onemessage class="im_msg im_f_in_row  position_rel  " style="">
<a class="oim_bigp_l  "><img onerror="this.src='/templates/Default/images/spacer.gif';this.classList.add('noSources');this.setAttribute('ordSrc', this.src);" src="https://tidevk.ru/uploads/users/1/50_hTrrxYyol9w0Ibxe72jnmWg4YClw8yHn.webp">
</a><div class="oim_bigp_r"><div class="msg_headIM"><left-h-im>
<span data-name="">AI</span>
</left-h-im>
<right-h-im class="position_rel"><span data-date=""></span>
</right-h-im></div><div class="msg_textIM">
<span class="im_msg_textPart">Подождите пожалуйста, мы генерируем ответ.<br /><span style="
    color: var(--text_color);
    opacity: 1;
    visibility: visible;
" id="im_typograf">Этот процесс может занять некоторое время</span></span></div></div></onemessage>
</div>

</div>
</div>

                                </div>

                                <progress_bar>
                                    <green>
                                        <label>
                                            <count>1</count>
                                            <span>Введите запрос</span>
                                        </label>
                                    </green>
                                    <green>
                                        <label>
                                            <count>2</count>
                                            <span>Получите ответ</span>
                                        </label>
                                    </green>
                                </progress_bar>

                            </div>
                            `,

}
