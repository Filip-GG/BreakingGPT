function ajax(options, callback, onload = null) {

    let xhr = new XMLHttpRequest(),
        requestBody = new FormData(),
        name = '',
        isJson = 0;

    if(tryJSON(options.body) !== false) {

        requestBody = options.body;
        isJson = 1;

    } else {

        if (typeof options.body !== 'object') {
            let split = options.body.split('&'),
                splitUrl;
            options.body = {};
            for (let i = 0; i < split.length; i++)
                if ((splitUrl = split[i].split('='))[1] != undefined) options.body[splitUrl[0]] = splitUrl[1];
        }

        for (name in options.body) requestBody.append(name, options.body[name]);

    }


    xhr.open(options.method, options.url, true);

    if(isJson === 1) xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

    xhr.send(
        requestBody
    );

    if (onload)
        xhr.onprogress = function (e) {

            let contentLength = (parseInt(e.target.getResponseHeader('content-length'))) ? (parseInt(e.target
                .getResponseHeader('content-length')) * 10) : parseInt(e.target.getResponseHeader(
                'x-decompressed-content-length'), 10);

            let progressIndicator = e.loaded / contentLength * -100;
            progressIndicator = parseInt(progressIndicator);
            onload(progressIndicator);

        };

    xhr.onloadend = function (e) {

        callback({status: this.status, response: xhr.responseText});

    };

}