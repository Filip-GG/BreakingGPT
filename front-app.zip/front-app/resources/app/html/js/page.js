let Page = {
    setPage: function(html, callback = null) {
        main.returnDiaCol();
        ge("page").innerHTML = html;
        resizeAllTextareas();
        executeScriptElements(ge("page"));
        if(callback !== null) callback();
    },
    switchRoute: function(alias, callback = null) {
        switch(alias) {
            case "err":
                ge("imRMTurnBack").classList.add("noDisplay");
                Page.setPage(tpl.errloadpage, callback);
                break;
            case "":
                ge("imRMTurnBack").classList.add("noDisplay");
                Page.setPage(tpl.mpage, callback);
                break;
            default:
                ge("imRMTurnBack").classList.add("noDisplay");
                Page.setPage(tpl.mpage, callback);
                break;
        }
    },
    Go: function(alias = '', callback = null) {
        Page.switchRoute(alias, callback);
    },
    Prev: function() {

    }
}

let pageFuncs = {
    def: function() {
        swiper = new Swiper(".mySwiper", {
            effect: "cards",
            grabCursor: true,
        });
        api.folder_list();
    },
}