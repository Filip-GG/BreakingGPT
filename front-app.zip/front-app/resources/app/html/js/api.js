var api = {
    attach_deleteP: function(title) {
        Box.Show('del_a', 400, 'Подтвердите действие:',
            '<div style="padding:15px"><div class="txtcenter"><br />Вы уверены, что хотите удалить файл '+title+'?<br />Необходимо будет запустить переобучение модели.</div><br /><div class="err_red txtcenter">Это действие отменить невозможно!!!</div><br /></div>', 'Отмена',
            'Да, удалить', 'api.attach_delete(`'+title+'`)');
    },
    attach_delete: function(title) {
        Box.Close("del_a");
        debugLog("Удаляем файл...");
        main.Loading("start");
        ajax({
            url: _T.api_domain+"/del_file",
            body: JSON.stringify({
                "type": "delete_file",
                "query": title
            }),
            method: "POST"
        }, (d) => {
            main.Loading("f");
            _T.inGen = 0;
            d = JSON.stringify(d);
            dA = tryJSON(d);

            if(intval(dA.status) === 200) {
                debugLog("Файл успешно удален.");
                document.querySelector(".wall_attach_doc[title='"+title+"']").remove();
            }

        });
    },
    folder_list: function() {

        main.Loading("start");
        debugLog("Получаем список файлов...");
        ajax({
            url: _T.api_domain+"/folder_list",
            body: JSON.stringify({
                "type": "folder_list",
                "query": "string"
            }),
            method: "POST"
        }, (d) => {

            main.Loading("f");

            _T.inGen = 0;
            d = JSON.stringify(d);
            dA = tryJSON(d);
            if(intval(dA.status) !== 200) {
                Page.Go("err");
                ge("aiAdmZone").classList.add("noDisplay");
                debugLog("Невозможно загрузить список файлов. Попросите администратора проверить, доступен ли сервер генерации ответов.");
                return false;
            }

            ge("aiAdmZone").classList.remove("noDisplay");

            files = Array.from(tryJSON(dA.response));
            if(files.length > 0) {

                ge("apiFiles").innerHTML = '';
                files.forEach(file => {ge("apiFiles").insertHTML(str_replace("{title}", file, tpl.file), 0)});
            }


        });

    },
    start_rog_P: function() {
        Box.Show('del_', 400, 'Подтвердите действие:',
            '<div style="padding:15px"><div class="txtcenter"><br />Вы уверены, что хотите запустить переобучение модели?</div><br /><div class="err_red txtcenter">Это действие отменить невозможно!!!</div><br /></div>', 'Отмена',
            'Да, запустить', 'api.start_rog()');
    },
    start_rog: function() {

        main.Loading("start");
        Box.Close("del_");
        debugLog("Создан запрос на переобучение...");

        ajax({
            url: _T.api_domain+"/admin",
            body: JSON.stringify({
                "type": "start_rog",
                "query": "string"
            }),
            method: "POST"
        }, (d) => {

            _T.inGen = 0;
            d = JSON.stringify(d);
            dA = tryJSON(d);
            debugLog(dA.response);
            main.Loading("f");

        });

    },
    query: function() {

        if(_T.inGen === 1) return false;
        _T.inGen = 1;

        let prompt = ge("mPromptInp").value;
        ge("mPromptInp").value = "";
        ge("mPromptInp").placeholder = "Обрабатываем запрос, подождите...";
        ge("mPromptInp").setAttribute("disabled", "");
        ge("mPromptInp").classList.add("mPromptDis");
        if(prompt === '' || prompt.length === 0) return false;

        ge("aiPrBar").innerHTML = (tpl.prbar1)
        ge("sliderCont").insertAdjacentHTML("afterbegin", str_replace(["{text}"], [prompt], tpl.slide));
        swiper.update();

        debugLog("Запрос? "+prompt);

        ajax({
            url: _T.api_domain+"/user",
            body: JSON.stringify({
                "type": "query",
                "query": prompt
            }),
            method: "POST"
        }, (d) => {

            _T.inGen = 0;
            d = JSON.stringify(d);
            debugLog("JSON-Ответ: "+d);

            dA = tryJSON(d);

            d = dA.response;
            console.log(dA);
            if(dA.status !== 200) {
                dA.status = intval(dA.status);

                switch(dA.status) {
                    default:
                        d = "Возникла непредвиденная ошибка сервера.<br />Проверьте, что сервер для генерации ответов включен и исправно функционирует.";
                }
                d = str_replace(["{text}"], [d], tpl.errbl);
            } else {

            }
            Array.from(document.querySelectorAll(".AIText"))[0].innerHTML = str_replace(["\n"], ["<br />"], d);
            ge("aiPrBar").innerHTML = (tpl.prbar2)
            ge("mPromptInp").removeAttribute("disabled");
            ge("mPromptInp").placeholder = "Теперь можно ввести новый запрос";
            ge("mPromptInp").classList.remove("mPromptDis");

        });

    },
    docLoad: function(form, progclb = null) {

        let input_files = document.getElementById(form).files[0];
        let url_load = _T.api_domain+"/uploloadfile";
        if (!input_files) {
            return false;
        }

        main.Loading("start");
        ge("aiLoadClck").classList.add("noDisplay");
        ge("aiLoadWait").classList.remove("noDisplay");

                let formData = new FormData();

                formData.append("uploaded_file", input_files);

                var ajax = new XMLHttpRequest();

                ajax.upload.onprogress = function(event) {
                    if(progclb) progclb((event.loaded / event.total) * 100)
                };

                ajax.onreadystatechange = function () {

                    if (this.readyState == 4) {
                        if(this.status == 200) {

                            result = this.response;
                            debugLog(this.response);
                            api.folder_list();

                        } else {

                            debugLog("Ошибка загрузки файлов. Проконсультируйтесь с администратором. Подробнее: "+this.response);

                        }

                        ge("aiLoadClck").classList.remove("noDisplay");
                        ge("aiLoadWait").classList.add("noDisplay");
                        main.Loading("f");

                    }

                };

                ajax.open("POST", url_load);
                ajax.send(formData);


    },
}