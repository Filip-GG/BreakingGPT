
//MODAL BOX
var Box = {
    Loading: function (start = 0) {

        if (start == 1) {

            _T.loaderWrapHscrtopf = intval(_T.clVwPH*0.15);
            _T.loaderWrapHscrtopt = intval(_T.clVwPH*0.15) - 0;

            ge("loaderWrap").classList.remove('noDisplay');
            setStyle(ge('loaderWrapDot'), 'top', _T.loaderWrapHscrtopf);
            animate(ge('loaderWrapDot'), {opacity: 1, top: _T.loaderWrapHscrtopt, transition: Fx.Transitions.linear}, 100);

        } else {
            animate(ge('loaderWrapDot'), {opacity: 0.7, top: _T.loaderWrapHscrtopf, transition: Fx.Transitions.linear}, 100, () => {ge("loaderWrap").classList.add('noDisplay')});
        }

    },
    footerLoad: function (s) {
        if (s == 1)
            ge('box_loading').classList.remove('noDisplay');
        else
            ge('box_loading').classList.add('noDisplay');
    },
    Call: function (d) {

        if (!d.html && !d.url) return false;

        if (d.html)
            Box.Show(
                d.name ? d.name : (Math.floor(Math.random() * (1000 - 1 + 1)) + 1),
                d.width ? d.width : 300,
                d.title ? d.title : '',
                d.html,
                d.cancel_text ? d.cancel_text : lang_box_canсel,
                d.func_text ? d.func_text : lang_box_yes,
                d.func ? d.func : 'return false;',
                d.height ? d.height : null,
                d.overflow ? d.overflow : null,
                null,
                null,
                null,
                d.not_animate ? 1 : 0,
            )
        else
            Box.Page(
                d.url,
                d.data ? d.data : null,
                d.name ? d.name : (Math.floor(Math.random() * (1000 - 1 + 1)) + 1),
                d.width ? d.width : 300,
                d.title ? d.title : '',
                d.cancel_text ? d.cancel_text : lang_box_canсel,
                d.func_text ? d.func_text : ((d.func) ? lang_box_yes : null),
                d.func ? d.func : 'return false;',
                d.height ? d.height : null,
                d.overflow ? d.overflow : null,
                null,
                null,
                null,
                null,
                d.not_animate ? 1 : 0,
            )

    },
    Page: function (url, data, name, width, title, cancel_text, func_text, func, height, overflow, bg_show = 0,
                    bg_show_bottom = 0, input_focus = null, cache = 0, not_animate = 0) {
        //url - ссылка которую будем загружать
        //data - POST данные
        //name - id окна
        //width - ширина окна
        //title - заголовк окна
        //content - контент окна
        //close_text - текст закрытия
        //func_text - текст который будет выполнять функцию
        //func - функция текста "func_text"
        //height - высота окна
        //overflow - постоянный скролл
        //bg_show - тень внтури окна сверху
        //bg_show_bottom - "1" - с тенью внтури, "0" - без тени внутри
        //input_focus - ИД текстового поля на котором будет фиксация
        //cache - "1" - кешировоть, "0" - не кешировать


            Box.Loading(1);

            let box_pos = ge('box_' + name);

            if (box_pos != null && box_pos.hasClass('noDisplay')) {

                box_pos.classList.remove('noDisplay');
                box_pos.scrollTop = 0;

            } else {

                ajax({
                    url: url,
                    method: 'POST',
                    body: data,
                }, function (html) {
                    Box.Show(name, width, title, html, cancel_text, func_text, func, height, overflow,
                        bg_show, bg_show_bottom, cache, not_animate);
                });

            }

            Box.Loading(0);


    },
    Show: function (name, width, title, content, close_text, func_text, func, height, overflow, bg_show = 0,
                    bg_show_bottom = 0, cache = 0, not_animate = 0) {

        //name - id окна
        //width - ширина окна
        //title - заголовк окна
        //content - контент окна
        //close_text - текст закрытия
        //func_text - текст который будет выполнять функцию
        //func - функция текста "func_text"
        //height - высота окна
        //overflow - постоянный скролл
        //bg_show - вырезано
        //bg_show_bottom - вырезано
        //cache - вырезано

            let func_but = (func_text) ?
                '<div class="button_div" style="margin-right:10px;" id="box_but"><button onClick="' + func +
                '" id="box_butt_create">' + func_text + '</button></div>' : '';

            let close_but = '<div class="button_div_gray"><button onClick="Box.Close(\'' + name + '\', ' +
                cache +
                '); return false;">' + close_text + '</button></div>';

            let box_loading = '<img id="box_loading" class="noDisplay" src="' + _T.template_dir +
                '/images/icons/loader_spin_r.svg" alt="" />';

            overflow = (overflow) ? 'overflow-y:scroll;' : '';

            let sheight = (height) ? 'height:' + height + 'px' : '';


            let box_pos = ge('box_' + name);

            not_animate = (not_animate == 1 || box_pos != null) ? 'box_noAnim' : '';

            let boxContent = '<div class="box_bg ' + not_animate + '" style="width:' + width +
                'px;"><div class="box_title" id="box_title_' + name + '"><span>' + title +
                '</span><div class="box_close" onClick="Box.Close(\'' + name + '\', ' + cache +
                '); return false;"></div></div><div class="box_conetnt" id="box_content_' + name + '" style="' +
                sheight + ';' + overflow + '">' + content +
                '<div class="clear"></div></div><div class="box_footer"><div id="box_bottom_left_text" class="fl_l">' +
                box_loading + '</div><div class="but_footer_wrap">' + close_but + func_but +
                '</div></div></div>';

            if (box_pos != null) {

                box_pos.scrollTop = 0;
                box_pos.innerHTML = '';
                box_pos.insertAdjacentHTML("beforeEnd", boxContent);
                executeScriptElements(box_pos);

            } else {

                document.body.insertAdjacentHTML("beforeEnd", '<div id="box_' + name + '" class="box_pos">' +
                    boxContent + '</div>');


                box_pos = ge('box_' + name);
                executeScriptElements(box_pos);

            }

    },
    Close: function (name, cache = 0) {

        let box_pos = ge('box_' + name);

        if (box_pos) {

            let box_bg = box_pos.querySelector("div");
            box_bg.classList.add('box_bg_closeAnimation');

            setTimeout(() => {

                box_pos.remove();

            }, 200);

        }

    },
}
