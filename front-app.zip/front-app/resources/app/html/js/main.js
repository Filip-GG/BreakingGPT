let main = {
    openRM: function(did) {

        ge("setupColWr_"+did).classList.add("VI");
        animate(ge("setupColWr_"+did), {opacity: 1, right: 0, transition: Fx.Transitions.linear}, 200, () => {    });

    },
    returnDiaCol: function(did) {
        animate(ge("setupColWr_"+did), {opacity: 0, right: -50, transition: Fx.Transitions.linear}, 200, () => {ge("setupColWr_"+did).classList.remove("VI")});
    },

    domStarted: () => {
        debugLog("Приложение запущено");
        _T.clVwPW = parseInt(Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0));
        _T.clVwPH = parseInt(Math.max(document.documentElement.clientHeight || 0, window.innerWidth || 0));
        Page.Go("", pageFuncs.def);
    },
    Loading: function (f) {

        if (f == 'start') {

            _T.loaderWrapHscrtopf = intval(_T.clVwPH*0.15);
            _T.loaderWrapHscrtopt = intval(_T.clVwPH*0.15) - 0;

            ge("loaderWrap").classList.remove('noDisplay');
            setStyle(ge('loaderWrapDot'), 'top', _T.loaderWrapHscrtopf);
            animate(ge('loaderWrapDot'), {opacity: 1, top: _T.loaderWrapHscrtopt, transition: Fx.Transitions.linear}, 100);

        } else {
            animate(ge('loaderWrapDot'), {opacity: 0.7, top: _T.loaderWrapHscrtopf, transition: Fx.Transitions.linear}, 100, () => {ge("loaderWrap").classList.add('noDisplay')});
        }

    },
}

